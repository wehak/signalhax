const regex = /[A-Z]{3}-[0-9]{2}-[A-Z]-[0-9]{5}/gi;
var bkg = chrome.extension.getBackgroundPage();

function getList (inputStr, searchPattern) {
  return inputStr.match(searchPattern)
}

// This event is fired with the user accepts the input in the omnibox.
chrome.omnibox.onInputEntered.addListener(
    function(text) {
      // Encode user input for special characters , / ? : @ & = + $ #
      results = getList(text, regex)
      if (results != null) {
        var newURL = 'https://proarc.banenor.no/locator.aspx?name=Document.UrlSearch.30&dbrno=12&doc_id=IN(' + encodeURIComponent(results.join(",")) + ')';
        chrome.tabs.create({ url: newURL });
        bkg.console.log(results.join(","))
      }
      else {
        var newURL = 'https://proarc.banenor.no/locator.aspx?name=Document.UrlSearch.30&dbrno=12&doc_id=IN()';
        chrome.tabs.create({ url: newURL });
        bkg.console.log(results)
      }
    });

